from . import Stock
from . import TransactionLog
from . import PortSummarize as ps
from . import CommissionService
import pandas as pd
import os
import bisect
import logging


class execution:
    PortSummarize = ps.summarize

    def __init__(
        self,
        team_name,
        orders_book=None,
        result_dir=None,
    ):
        self.Orders_Book = orders_book if orders_book is not None else []
        self.tranLog = TransactionLog.Transaction(team_name, folder=result_dir)
        # symbol -> {"Buy": shares bought today, "Sell": shares sold today};
        # tradeSim takes these off the day's volume cap.
        self.filled_volume = {}
        # Shares of the current tick the team's orders already took; reset
        # by start_tick() on every tick (tradeSim.record_tick).
        self._tick_taken = 0
        self._tick_key = None

    def addOrderToOrders_Book(self, new_order, row):
        if new_order is None:
            return "Cannot add an invalid/None order."
        if new_order.get_side() == "Buy":
            self.Orders_Book.append(new_order)
            return f"Order {new_order.get_order_number()} added to book ({new_order.get_symbol()})."
        elif new_order.get_side() == "Sell":
            self.Orders_Book.append(new_order)
            return f"Order {new_order.get_order_number()} added to book ({new_order.get_symbol()})."

    def start_tick(self):
        """A new tick has arrived: none of its volume is taken yet."""
        self._tick_taken = 0
        self._tick_key = None

    def _tick_lots_left(self, row):
        """Shares of this tick still free for the team's orders, in whole
        lots of 100: its volume less what earlier orders on it took. A row
        other than the one counted so far starts from zero too, for callers
        that place orders without tradeSim.record_tick()."""
        key = (row["ShareCode"], row["TradeDateTime"], row["LastPrice"], row["Volume"], row.get("Flag"))
        if key != self._tick_key:
            self._tick_key = key
            self._tick_taken = 0
        return int(row["Volume"]) // 100 * 100 - self._tick_taken

    def isMatch(self, row):
        """Try the limit orders for this tick's stock against it -- once.

        Every order is IOC. It is tried on the first tick of its own stock
        after it is placed (the very tick it was placed on, when it is for
        the bar's own stock) and then leaves the book whatever happened: it
        filled, filled in part, or did not fill. Orders for other stocks are
        left alone until their own stock's next tick. Orders are tried in
        the order they were placed and share the tick's volume.
        """
        for order in list(self.Orders_Book):  # copy: orders leave the book inside the loop
            if order.get_symbol() != row["ShareCode"]:
                continue
            if row["TradeDateTime"] < pd.to_datetime(order.get_placed_timestamp(), unit="s"):
                continue
            self.removeOrder(order)
            fill = self._limit_fill_price(row, order)
            if fill is None:
                continue
            qty = min(order.get_remaining_volume(), self._tick_lots_left(row))
            if qty <= 0:
                continue
            is_valid, _ = self.validate_order(
                qty, order.get_side(), order.get_symbol(),
                order.get_ownerPortfolio(), fill, slippage=False,
            )
            if not is_valid:
                continue
            order.mark_filled(row, fill, qty)
            self._process_fill(order)

    @staticmethod
    def _limit_fill_price(row, order):
        """The price a limit order gets on this tick, or None if it doesn't fill.

        The other side's best quote is taken to be the last price one tick
        away (the slippage rule): a Buy fills if that is at or below its
        limit and pays it, a Sell fills if it is at or above its limit.
        Auction prints (OPEN1_E, OPEN2_E, ATC) -- any tick whose Flag is not
        Buy or Sell -- have no quote and fill nothing.
        """
        if row.get("Flag") not in ("Buy", "Sell"):
            return None
        fill = CommissionService.commissionService.market_fill_price(
            row["LastPrice"], order.get_side(), row["TradeDateTime"]
        )
        if order.get_side() == "Buy":
            return fill if fill <= order.get_price() + 1e-9 else None
        return fill if fill >= order.get_price() - 1e-9 else None

    def isMatchMarketOrder(self, row, market_order):
        """A market (Market-to-Limit IOC) order fills at once at the last
        price one tick against it, for at most what is left of this tick's
        volume; the rest is cancelled. Nothing fills on an auction print, or
        if the cash or shares aren't there."""
        if market_order is None:
            return
        number = market_order.get_order_number()
        if row["ShareCode"] != market_order.get_symbol():
            return f"Market order {number} is not for this tick's stock."
        if row.get("Flag") not in ("Buy", "Sell"):
            return (f"Market order {number} could not be filled: tick {row['TradeDateTime']} is an "
                    f"auction print ({row.get('Flag')}), not continuous trading.")
        qty = min(market_order.get_remaining_volume(), self._tick_lots_left(row))
        if qty <= 0:
            return f"Market order {number} could not be filled: no volume left on this tick."
        is_valid, _ = self.validate_order(
            qty, market_order.get_side(), market_order.get_symbol(),
            market_order.get_ownerPortfolio(), row["LastPrice"], slippage=True,
            trade_date=row["TradeDateTime"],
        )
        if not is_valid:
            return f"Market order {number} could not be filled."
        fill = CommissionService.commissionService.market_fill_price(
            row["LastPrice"], market_order.get_side(), row["TradeDateTime"]
        )
        market_order.mark_filled(row, fill, qty)
        self._process_fill(market_order)

    def validate_order(self, volume, side, symbol, ownerPortfolio, price, slippage=True, trade_date=None):
        cashBalance = ownerPortfolio.get_cash_balance()
        
        if (volume % 100.0) != 0 and volume > 0:
            return False, "Volume must be a multiple of 100.SS S"
        
        if side.capitalize() not in {"Buy", "Sell"}:
            return False, f"Invalid side '{side}'. Must be 'Buy' or 'Sell'. Case sensitive."
        
        if (
            CommissionService.commissionService.verify_transaction(
                volume=volume, price=price, cashBalance=cashBalance, slippage=slippage,
                trade_date=trade_date,
            )
            == False
            and side == "Buy"
        ):
            return False, "Insufficient cash balance to cover transaction costs."

        if ownerPortfolio.has_stock(symbol, volume) == False and side == "Sell":
            print(f"Cannot sell {symbol} as it is not in the portfolio or insufficient volume.")
            return False, f"Cannot sell {symbol} as it is not in the portfolio or insufficient volume."

        return True, ""

    def _process_fill(self, order):
        """Book an order's latest fill (limit or market) at its fill price and log it."""
        if order.get_side() == "Buy":
            self._process_buy_order(order)
        else:
            self._process_sell_order(order)
        filled = self.filled_volume.setdefault(order.get_symbol(), {"Buy": 0, "Sell": 0})
        filled[order.get_side()] += order.get_last_fill_volume()
        self._tick_taken += order.get_last_fill_volume()
        self.tranLog.create_transaction_log(order)

    def _unit_value(self, order):
        return CommissionService.commissionService.cal_unit_cost(
            order.get_last_fill_volume(), order.get_fill_price(), order.get_side()
        )

    # The two names below are load-bearing: Portfolio.add_stock() only
    # accepts calls from a function called _process_buy_order.
    # Every fill of one order goes into one lot and counts as one order --
    # see Portfolio.add_stock / decrease_stock_volume.
    def _process_buy_order(self, order):
        unit_value = self._unit_value(order)
        volume = order.get_last_fill_volume()
        new_stock = Stock.stock(
            order.get_symbol(),
            volume,
            unit_value,
            order.get_price(),
            order.get_timestamp(),
            opened_at_order=order.get_order_number(),
        )
        order.get_ownerPortfolio().add_stock(new_stock)
        order.get_ownerPortfolio().update_Buy_stock_valueToPort(unit_value * volume)

    def _process_sell_order(self, order):
        unit_value = self._unit_value(order)
        volume = order.get_last_fill_volume()
        order.get_ownerPortfolio().decrease_stock_volume(
            order.get_symbol(), volume, unit_value,
            closed_by_order=order.get_order_number(),
            close_timestamp=order.get_timestamp(),
            count_order=order.is_first_fill(),
        )
        order.get_ownerPortfolio().update_sold_stock_valueToPort(unit_value * volume)

    def removeOrder(self, order):
        self.Orders_Book.remove(order)

    def getOpenOrders(self, symbol=None):
        return [o.get_order_info() for o in self.Orders_Book
                if symbol is None or o.get_symbol() == symbol]

    def cancelOrder(self, order_number):
        for o in self.Orders_Book:
            if o.get_order_number() == order_number:
                self.removeOrder(o)
                return True
        return False

    def cancelAllOrders(self, symbol=None):
        to_cancel = [o for o in self.Orders_Book if symbol is None or o.get_symbol() == symbol]
        for o in to_cancel:
            self.removeOrder(o)
        return len(to_cancel)

    def getOrderbooksSize(self):
        return len(self.Orders_Book)

    def isOrderbooksEmpty(self):
        return self.getOrderbooksSize() == 0

    def flushTransactionLog(self):
        self.tranLog.flush_logs()
import bisect
import json
import math
import os
from datetime import date, datetime


TICK_SIZE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tick_size.json")


class TickSizeError(Exception):
    pass


def _as_date(trade_date):
    """A datetime.date from a date, datetime / pd.Timestamp, or 'YYYY-MM-DD...'
    string. None means today -- for tools that price without a trading day."""
    if trade_date is None:
        return date.today()
    if isinstance(trade_date, datetime):
        return trade_date.date()
    if isinstance(trade_date, date):
        return trade_date
    return date.fromisoformat(str(trade_date)[:10])


class commissionService:

    comm = 0.00157
    vat = 0.07

    # Tick sizes live only in tick_size.json. It is read once per run, on the
    # first lookup; after that every lookup is a dict hit and one bisect.
    tick_size_file = TICK_SIZE_FILE
    _tick_tables = None    # [(effective_from, bounds, ticks)], oldest first
    _tick_by_date = {}     # trading date -> (bounds, ticks) of the table in force

    @classmethod
    def _reset_tick_cache(cls, path=None):
        """Forget the loaded tables; the next lookup reads `path` (default:
        tradeSim/tick_size.json). For tests."""
        cls.tick_size_file = path or TICK_SIZE_FILE
        cls._tick_tables = None
        cls._tick_by_date = {}

    @classmethod
    def _load_tick_tables(cls):
        path = cls.tick_size_file

        def tick_file_error(reason):
            return TickSizeError(f"[ERROR] Tick size file '{path}': {reason}")

        try:
            with open(path, "r", encoding="utf-8") as f:
                raw = json.load(f)
        except FileNotFoundError:
            raise tick_file_error("not found -- the engine has no tick sizes without it")
        except json.JSONDecodeError as e:
            raise tick_file_error(f"not valid JSON ({e})")

        tables = []
        for t in raw.get("tables") or []:
            try:
                start = date.fromisoformat(t["effective_from"])
                steps = t["steps"]
            except (KeyError, TypeError, ValueError):
                raise tick_file_error("every table needs an 'effective_from' (YYYY-MM-DD) and 'steps'")
            if not steps or steps[-1].get("below") is not None:
                raise tick_file_error(f"table from {start}: the last step must have \"below\": null")
            bounds = [s.get("below") for s in steps[:-1]]
            ticks = [s.get("tick") for s in steps]
            if any(not isinstance(b, (int, float)) for b in bounds) or bounds != sorted(set(bounds)):
                raise tick_file_error(f"table from {start}: 'below' values must be numbers in ascending order")
            if any(not isinstance(k, (int, float)) or k <= 0 for k in ticks):
                raise tick_file_error(f"table from {start}: every 'tick' must be a number > 0")
            tables.append((start, bounds, ticks))

        if not tables:
            raise tick_file_error("no tables")
        starts = [t[0] for t in tables]
        if starts != sorted(set(starts)):
            raise tick_file_error("tables must be in ascending 'effective_from' order")
        cls._tick_tables = tables

    @classmethod
    def _table_for(cls, trade_date):
        day = _as_date(trade_date)
        found = cls._tick_by_date.get(day)
        if found is None:
            if cls._tick_tables is None:
                cls._load_tick_tables()
            i = bisect.bisect_right([t[0] for t in cls._tick_tables], day) - 1
            if i < 0:
                raise TickSizeError(
                    f"[ERROR] Tick size file '{cls.tick_size_file}' has no table in force on {day}"
                )
            found = cls._tick_by_date[day] = cls._tick_tables[i][1:]
        return found

    @classmethod
    def _get_slippage(cls, price: float, trade_date=None) -> float:
        """The tick size (one price step) at `price` on `trade_date`."""
        bounds, ticks = cls._table_for(trade_date)
        return ticks[bisect.bisect(bounds, price)]

    @classmethod
    def _tick_below(cls, price, trade_date=None):
        """The tick size between `price` and the next valid price under it.
        Same as _get_slippage except exactly on a band edge, where the price
        below is in the lower band: 100.00 -> 0.25 (to 99.75), not 0.50."""
        bounds, ticks = cls._table_for(trade_date)
        return ticks[bisect.bisect_left(bounds, price)]

    @classmethod
    def is_valid_tick_price(cls, price, trade_date=None):
        """Whether `price` is a whole number of ticks at its own price level.
        The 1e-6 (of a tick) tolerance absorbs float noise like
        2.24 + 0.02 = 2.2600000000000002."""
        steps = price / cls._get_slippage(price, trade_date)
        return abs(steps - round(steps)) <= 1e-6

    @classmethod
    def nearest_tick_prices(cls, price, trade_date=None):
        """The valid prices just below and above an off-tick `price`."""
        tick = cls._get_slippage(price, trade_date)
        lower = math.floor(price / tick) * tick
        return round(lower, 2), round(lower + tick, 2)

    @classmethod
    def market_fill_price(cls, last_price, side, trade_date=None):
        """What an order fills at: the last price one tick against you
        (Buy pays more, Sell gets less), standing in for the other side's
        best quote. Rounded to satang so it compares cleanly with a limit."""
        if side == "Buy":
            fill = last_price + cls._get_slippage(last_price, trade_date)
        else:
            fill = last_price - cls._tick_below(last_price, trade_date)
        return round(fill, 2)

    @classmethod
    def cal_unit_cost(cls, volume, match_price, side):
        """Per-share cash paid (Buy) or received (Sell) for a fill at
        match_price, commission and VAT included."""
        amount = match_price * volume
        comm_amount = amount * cls.comm
        vat = comm_amount * cls.vat
        if side == "Buy":
            return (amount + comm_amount + vat) / volume
        elif side == "Sell":
            return (amount - comm_amount - vat) / volume

    @classmethod
    def verify_transaction(cls, volume, price, cashBalance, slippage=True, trade_date=None):
        """Whether cashBalance covers buying `volume` at `price`, fees included.
        slippage=True prices it like a market order (one step up); a limit
        order passes False, since it never pays more than its own price."""
        if slippage:
            total = cls.cal_All_Volume_commissionAndVat(volume, price, trade_date)
        else:
            total = cls.cal_unit_cost(volume, price, "Buy") * volume
        return cashBalance >= total

    @classmethod
    def cal_All_Volume_commissionAndVat(cls, volume, price, trade_date=None):
        match_price = cls.market_fill_price(price, "Buy", trade_date)
        amount = match_price * volume
        comm_amount = amount * cls.comm
        vat = comm_amount * cls.vat
        return amount + comm_amount + vat

    @classmethod
    def cal_commissionAndVat(cls, volume, price, side, trade_date=None):
        """Per-share cost of a market order at last price `price`: one step of
        slippage, then commission and VAT."""
        if side not in ("Buy", "Sell"):
            return None
        return cls.cal_unit_cost(volume, cls.market_fill_price(price, side, trade_date), side)

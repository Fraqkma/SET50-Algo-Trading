import time
import csv
import os
import bisect
from datetime import datetime, timedelta
from . import CommissionService


# Index names a strategy might reasonably try to order by mistake -- they
# can be read through get_historical_data() but never held.
INDEX_SYMBOLS = {"SET", "SET50", "SET100", "MAI", "SETHD"}


def tick_timestamp(mkt_data):
    """The timestamp the engine stores on an order for a given tick: when it
    was placed, and again when a resting order fills, so the stock's buy and
    sell times are the tick it actually traded on."""
    return (mkt_data["TradeDateTime"] - timedelta(hours=7)).timestamp()


class order:
    _order_counter = 1
    _set50_symbols = set()
    _csv_loaded = False

    @classmethod
    def load_set50_symbols(cls, csv_path=None):
        if cls._csv_loaded:
            return

        if csv_path is None:
            base_dir = os.path.dirname((__file__))
            csv_path = os.path.join(
                base_dir, "..", "marketInfo", "symbolSET50", "Symbol_SET50.csv"
            )
            csv_path = os.path.abspath(csv_path)

        if not os.path.exists(csv_path):
            raise FileNotFoundError(f"[ERROR] Cannot find SET50 list at '{csv_path}'")

        with open(csv_path, mode="r", newline="", encoding="utf-8-sig") as file:
            reader = csv.DictReader(file)
            headers = [h.strip() for h in reader.fieldnames]

            symbol_col = None
            for h in headers:
                if h.lower() == "symbol":
                    symbol_col = h
                    break
            if symbol_col is None:
                raise KeyError("[ERROR] 'Symbol' column not found in CSV headers.")

            for row in reader:
                symbol = row[symbol_col].strip().upper()
                cls._set50_symbols.add(symbol)

        cls._csv_loaded = True

    def __init__(
        self,
        ownerPortfolio,
        volume,
        price,
        side,  # 'Buy' or 'Sell'
        symbol,
        cum_sell_volume,
        cum_buy_volume,
        timestamp=None,
        order_type="Limit",  # 'Limit' or 'Market'
        trade_date=None,  # the tick's trading day: picks the tick size table
    ):
        order.load_set50_symbols()
        self.order_type = order_type
        self.trade_date = trade_date
        is_valid, reason = self.validate_order(
            volume, side, symbol, ownerPortfolio, price, cum_sell_volume, cum_buy_volume
        )
        if not is_valid:
            raise ValueError(
                f"[ERROR] Order for {symbol} (Vol: {volume}, Price: {price}, Side: {side}) skipped due to {reason}"
            )
        order_ts = timestamp if timestamp is not None else time.time()
        date_prefix = datetime.fromtimestamp(order_ts).strftime("%Y%m%d")
        self.order_number = f"{date_prefix}-ORD{order._order_counter:05d}"
        order._order_counter += 1

        self.ownerPortfolio = ownerPortfolio
        self.volume = volume
        self.price = price
        self.side = side
        self.symbol = symbol
        self.cum_sell_volume = cum_sell_volume
        self.cum_buy_volume = cum_buy_volume
        self.timestamp = timestamp if timestamp is not None else time.time()
        self.placed_timestamp = self.timestamp
        self.fill_price = None
        self.fill_market_price = None
        # An order is IOC: it fills at most the volume of the one tick it is
        # tried on, and the rest is cancelled. These follow that fill;
        # `volume` stays what was asked for; what can still fill starts at
        # what the day's volume cap leaves of it.
        self.remaining_volume = self.fillable_volume
        self.last_fill_volume = 0
        self.fill_count = 0


    def validate_order(self, volume, side, symbol, ownerPortfolio, price, cum_sell_volume, cum_buy_volume):
        cashBalance = ownerPortfolio.get_cash_balance()
        
        if (volume % 100.0) != 0 and volume > 0:
            return False, "Volume must be a multiple of 100.SS S"
        
        if side.capitalize() not in {"Buy", "Sell"}:
            return False, f"Invalid side '{side}'. Must be 'Buy' or 'Sell'. Case sensitive."
        
        if symbol.upper() not in self._set50_symbols:
            # An index name gets its own message. "Symbol 'SET50' is not in
            # SET50." is technically accurate and reads like a bug, and the
            # mistake behind it is a specific one worth answering directly:
            # the index is readable history, not something you can hold.
            if symbol.upper() in INDEX_SYMBOLS:
                return False, (
                    f"'{symbol}' is a market index, not a tradable stock -- orders can only be "
                    f"placed on the individual SET50 constituent stocks (AOT, PTT, ...). "
                    f"To read the index itself, use get_historical_data('{symbol.upper()}', n)."
                )
            return False, (
                f"Symbol '{symbol}' is not one of the tradable SET50 stocks "
                f"(see marketInfo/symbolSET50/Symbol_SET50.csv for the full list)."
            )
        
        if self.order_type == "Limit":
            if price <= 0:
                return False, f"Limit price must be greater than 0 (got {price})."
            cs = CommissionService.commissionService
            if not cs.is_valid_tick_price(price, self.trade_date):
                tick = cs._get_slippage(price, self.trade_date)
                lower, upper = cs.nearest_tick_prices(price, self.trade_date)
                return False, (
                    f"Price {price} is not a valid price for {symbol.upper()}: the tick size at this "
                    f"price is {tick:.2f} baht, so the price must be a multiple of {tick:.2f} "
                    f"(nearest valid prices: {lower:.2f} or {upper:.2f})."
                )

        if (
            CommissionService.commissionService.verify_transaction(
                volume=volume, price=price, cashBalance=cashBalance,
                slippage=(self.order_type == "Market"), trade_date=self.trade_date,
            )
            == False
            and side == "Buy"
        ):
            return False, "Insufficient cash balance to cover transaction costs."

        if ownerPortfolio.has_stock(symbol, volume) == False and side == "Sell":
            return (
                False,
                f"Cannot sell {symbol} as it is not in the portfolio or insufficient volume.",
            )
            
        # The day's volume cap: an order bigger than what is left of it is
        # not refused (IOC gets what the market has) but can fill at most
        # that, in whole lots; only an order with no lot left at all is.
        day_left = cum_sell_volume if side == "Buy" else cum_buy_volume
        self.fillable_volume = min(volume, int(day_left) // 100 * 100)
        if side == "Buy" and self.fillable_volume <= 0:
            return False, "Order's buy volume exceeds the cumulative sell volume from the daily ticks."

        if side == "Sell" and self.fillable_volume <= 0:
            return False, "Order's sell volume exceeds the cumulative buy volume from the daily ticks."

        return True, ""
        
        

    # --------- Getter Methods ---------
    def get_order_number(self):
        return self.order_number

    def get_ownerPortfolio(self):
        return self.ownerPortfolio

    def get_volume(self):
        return self.volume

    def get_price(self):
        return self.price

    def get_side(self):
        return self.side

    def get_symbol(self):
        return self.symbol

    def get_timestamp(self):
        return self.timestamp

    def get_formatted_timestamp(self):
        return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(self.timestamp))

    def get_order_type(self):
        return self.order_type

    def get_placed_timestamp(self):
        return self.placed_timestamp

    def get_formatted_placed_timestamp(self):
        return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(self.placed_timestamp))

    def get_fill_price(self):
        return self.fill_price

    def get_fill_market_price(self):
        return self.fill_market_price

    def mark_filled(self, mkt_data, fill_price, volume=None):
        """Record a fill of `volume` shares (default: all that is left): the
        price per share before fees, the market's last price on that tick,
        and the tick's time as the order's timestamp, so the stock's buy/sell
        time is when it actually traded."""
        volume = self.remaining_volume if volume is None else volume
        self.fill_price = fill_price
        self.fill_market_price = mkt_data["LastPrice"]
        self.timestamp = tick_timestamp(mkt_data)
        self.last_fill_volume = volume
        self.remaining_volume -= volume
        self.fill_count += 1

    def get_remaining_volume(self):
        """Shares not filled yet."""
        return self.remaining_volume

    def get_last_fill_volume(self):
        """Shares in the latest fill."""
        return self.last_fill_volume

    def is_first_fill(self):
        """True right after the order's first fill -- what counts it as one
        order, however many pieces it fills in."""
        return self.fill_count == 1

    def get_order_info(self):
        return {
            "Order Number": self.get_order_number(),
            "owner": self.ownerPortfolio.get_owner(),
            "Type": self.get_order_type(),
            "Volume": self.get_remaining_volume(),   # what is still waiting
            "Price": self.get_price(),
            "Side": self.get_side(),
            "Symbol": self.get_symbol(),
            "Timestamp": self.get_formatted_placed_timestamp(),
        }

    # --------- Setter Methods ---------
    def set_owner(self, owner):
        self.owner = owner

    def set_volume(self, volume):
        self.volume = volume

    def set_price(self, price):
        self.price = price

    def set_side(self, side):
        self.side = side

    def set_symbol(self, symbol):
        self.symbol = symbol